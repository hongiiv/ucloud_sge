#!/bin/sh
uname -r > /autoscale/hostname
