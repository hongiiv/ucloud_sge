.. ref-services

========
services
========

boto.services
-------------

.. automodule:: boto.services
   :members:   
   :undoc-members:

boto.services.bs
----------------

.. automodule:: boto.services.bs
   :members:   
   :undoc-members:

boto.services.message
---------------------

.. automodule:: boto.services.message
   :members:   
   :undoc-members:

boto.services.result
--------------------

.. automodule:: boto.services.result
   :members:   
   :undoc-members:

boto.services.service
---------------------

.. automodule:: boto.services.service
   :members:   
   :undoc-members:

boto.services.servicedef
------------------------

.. automodule:: boto.services.servicedef
   :members:   
   :undoc-members:

boto.services.sonofmmm
----------------------

.. automodule:: boto.services.sonofmmm
   :members:   
   :undoc-members:

boto.services.submit
--------------------

.. automodule:: boto.services.submit
   :members:   
   :undoc-members:
